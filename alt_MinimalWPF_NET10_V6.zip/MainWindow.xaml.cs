﻿//-----------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="$companyname$">
//     Class: MainWindow
//     Copyright © $companyname$ $year$
// </copyright>
// <Template>
// 	Version 3.0.2026.4, 15.04.2026
// </Template>
//
// <author>$author$ - $companyname$</author>
// <email>$email$</email>
// <date>$time$</date>
//
// <summary>
// WPF Template mit Minimalfunktionen und rudimentären ViewModel-Funktionen
// </summary>
//-----------------------------------------------------------------------

namespace $safeprojectname$
{
    using System.ComponentModel;
    using System.Windows;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : WindowBase
    {
        public MainWindow()
        {
            this.InitializeComponent();
            WeakEventManager<WindowBase, RoutedEventArgs>.AddHandler(this, "Loaded", this.OnLoaded);
            WeakEventManager<WindowBase, CancelEventArgs>.AddHandler(this, "Closing", this.OnWindowClosing);

            this.QuitCommand = new CommandBase(this.OnQuit);
            this.QuitParamCommand = new CommandBase(() => this.OnQuit("Argument"));
            this.StartCommand = new CommandBase(OnStart);

            this.WindowTitel = LocalizationString.Get("WindowsTitelZeile");
            this.DataContext = this;
        }

        public CommandBase QuitCommand { get; private set; }
        public CommandBase QuitParamCommand { get; private set; }
        public CommandBase StartCommand { get; private set; }

        public string WindowTitel
        {
            get => base.GetValue<string>();
            set => base.SetValue(value);
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            StatusbarMain.Statusbar.DatabaseInfo = "Keine";
            StatusbarMain.Statusbar.DatabaseInfoTooltip = "Keine Datenbank verbunden";
            StatusbarMain.Statusbar.Notification = "Bereit";
        }

        private void OnCloseApplication(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void OnQuit()
        {
            this.Tag = null;
            this.Close();
        }

        private void OnStart()
        {
            this.QuitParamCommand.TryExecute();
        }

        private void OnQuit(string param)
        {
            this.Tag = param;
            this.Close();
        }

        private void OnWindowClosing(object sender, CancelEventArgs e)
        {
            e.Cancel = false;

            MessageBoxResult msgYN;
            if (this.Tag != null)
            {
                msgYN = MessageBox.Show($"Wollen Sie die Anwendung beenden? ({this.Tag})", "Beenden", MessageBoxButton.YesNo, MessageBoxImage.Question);
            }
            else
            {
                msgYN = MessageBox.Show("Wollen Sie die Anwendung beenden?", "Beenden", MessageBoxButton.YesNo, MessageBoxImage.Question);
            }

            if (msgYN == MessageBoxResult.Yes)
            {
                App.ApplicationExit();
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}